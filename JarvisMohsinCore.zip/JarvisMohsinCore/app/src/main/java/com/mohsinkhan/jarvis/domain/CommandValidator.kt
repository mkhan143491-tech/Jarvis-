package com.mohsinkhan.jarvis.domain

import com.mohsinkhan.jarvis.data.remote.JarvisResponse
import javax.inject.Inject

sealed class ValidatedAction {
    data class OpenApp(val appTarget: String) : ValidatedAction()
    data class OpenUrl(val url: String) : ValidatedAction()
    object OpenSettings : ValidatedAction()
    data class SearchWeb(val query: String) : ValidatedAction()
    object ShowInformation : ValidatedAction()
    data class SpeakOnly(val message: String) : ValidatedAction()
    object InvalidAction : ValidatedAction()
}

class CommandValidator @Inject constructor() {

    fun validate(response: JarvisResponse): ValidatedAction {
        if (response.type != "ACTION") return ValidatedAction.InvalidAction

        return when (response.action.uppercase()) {
            "OPEN_APP" -> {
                if (!response.target.isNullOrBlank()) ValidatedAction.OpenApp(response.target.lowercase())
                else ValidatedAction.InvalidAction
            }
            "OPEN_URL" -> {
                if (!response.target.isNullOrBlank() &&
                    (response.target.startsWith("http") || response.target.startsWith("https"))) {
                    ValidatedAction.OpenUrl(response.target)
                } else ValidatedAction.InvalidAction
            }
            "OPEN_SETTINGS" -> ValidatedAction.OpenSettings
            "SEARCH_WEB" -> {
                val query = response.parameters?.get("query") ?: response.target
                if (!query.isNullOrBlank()) ValidatedAction.SearchWeb(query)
                else ValidatedAction.InvalidAction
            }
            "SHOW_INFORMATION" -> ValidatedAction.ShowInformation
            "SPEAK", "NO_ACTION" -> ValidatedAction.SpeakOnly(response.spokenResponse)
            else -> ValidatedAction.InvalidAction
        }
    }
}
