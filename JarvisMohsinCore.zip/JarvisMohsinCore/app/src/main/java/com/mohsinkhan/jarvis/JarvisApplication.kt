package com.mohsinkhan.jarvis

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize core application level components if necessary
    }
}
