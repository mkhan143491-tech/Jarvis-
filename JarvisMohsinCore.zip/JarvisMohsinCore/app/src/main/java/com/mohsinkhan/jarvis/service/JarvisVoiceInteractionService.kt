package com.mohsinkhan.jarvis.service

import android.service.voice.VoiceInteractionService
import android.util.Log

class JarvisVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        Log.d("JARVIS_CORE", "Voice Interaction Service initialized. Ready to intercept system intents.")
    }

    // Core session routing logic sits here when acting as default assistant.
    // This establishes a persistent bridge to the Android OS ambient framework.
}
