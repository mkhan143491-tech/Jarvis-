package com.mohsinkhan.jarvis.device

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class AndroidActionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun executeAction(action: com.mohsinkhan.jarvis.domain.ValidatedAction): Boolean {
        return try {
            when (action) {
                is com.mohsinkhan.jarvis.domain.ValidatedAction.OpenApp -> openApplication(action.appTarget)
                is com.mohsinkhan.jarvis.domain.ValidatedAction.OpenUrl -> openUrl(action.url)
                is com.mohsinkhan.jarvis.domain.ValidatedAction.OpenSettings -> openSettings()
                is com.mohsinkhan.jarvis.domain.ValidatedAction.SearchWeb -> searchWeb(action.query)
                else -> false
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun openApplication(appName: String): Boolean {
        val pm = context.packageManager
        val packageName = resolvePackageName(appName) ?: return false

        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return true
        }
        return false
    }

    private fun openSettings(): Boolean {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    private fun openUrl(url: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    private fun searchWeb(query: String): Boolean {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return true
    }

    fun getDeviceTelemetry(): String {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { ifilter ->
            context.registerReceiver(null, ifilter)
        }
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level != -1 && scale != -1) (level * 100 / scale.toFloat()).toInt() else "Unknown"

        return "Battery: $batteryPct%, Android OS: ${Build.VERSION.RELEASE}, API: ${Build.VERSION.SDK_INT}"
    }

    private fun resolvePackageName(appName: String): String? {
        val appMap = mapOf(
            "youtube" to "com.google.android.youtube",
            "calculator" to "com.google.android.calculator",
            "browser" to "com.android.chrome",
            "chrome" to "com.android.chrome",
            "settings" to "com.android.settings",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android"
        )
        // Fuzzy logic matching can be implemented here; currently relies on direct mapping.
        return appMap[appName.lowercase()] ?: getInstalledPackagesMap()[appName.lowercase()]
    }

    private fun getInstalledPackagesMap(): Map<String, String> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)
        return packages.associate { pm.getApplicationLabel(it).toString().lowercase() to it.packageName }
    }
}
