package com.mohsinkhan.jarvis.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohsinkhan.jarvis.audio.TtsManager
import com.mohsinkhan.jarvis.data.remote.JarvisBackendApi
import com.mohsinkhan.jarvis.data.remote.JarvisRequest
import com.mohsinkhan.jarvis.device.AndroidActionManager
import com.mohsinkhan.jarvis.domain.CommandValidator
import com.mohsinkhan.jarvis.domain.ValidatedAction
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

enum class JarvisState {
    IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, ERROR
}

data class ChatMessage(
    val isFromBoss: Boolean,
    val text: String,
    val actionSummary: String? = null
)

@HiltViewModel
class JarvisViewModel @Inject constructor(
    private val api: JarvisBackendApi,
    private val commandValidator: CommandValidator,
    private val actionManager: AndroidActionManager,
    private val ttsManager: TtsManager
) : ViewModel() {

    private val _currentState = MutableStateFlow(JarvisState.IDLE)
    val currentState: StateFlow<JarvisState> = _currentState

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory

    fun processBossQuery(query: String) {
        viewModelScope.launch {
            _currentState.value = JarvisState.THINKING
            addMessageToChat(ChatMessage(isFromBoss = true, text = query))

            try {
                // Dynamic timestamp generation ensures JARVIS possesses temporal awareness
                val currentDateTime = SimpleDateFormat(
                    "EEEE, MMMM dd, yyyy 'at' hh:mm a",
                    Locale.getDefault()
                ).format(Date())

                val response = api.sendQuery(JarvisRequest(query, currentDateTime))
                val action = commandValidator.validate(response)

                executeValidatedAction(action, response.spokenResponse, response.action)
            } catch (e: Exception) {
                _currentState.value = JarvisState.ERROR
                val errorMsg = "Boss, internet connection available nahi hai, ya API server down hai. System offline."
                addMessageToChat(ChatMessage(isFromBoss = false, text = errorMsg))
                ttsManager.speak(errorMsg)
                resetToIdle()
            }
        }
    }

    private fun executeValidatedAction(
        action: ValidatedAction,
        spokenResponse: String,
        rawActionType: String
    ) {
        _currentState.value = JarvisState.EXECUTING
        var actionSummary: String? = null

        val executionSuccess = actionManager.executeAction(action)

        if (action is ValidatedAction.ShowInformation) {
            val telemetry = actionManager.getDeviceTelemetry()
            addMessageToChat(ChatMessage(isFromBoss = false, text = "$spokenResponse\nTelemetry: $telemetry"))
            ttsManager.speak(spokenResponse)
            resetToIdle()
            return
        }

        if (action !is ValidatedAction.SpeakOnly && action !is ValidatedAction.InvalidAction) {
            actionSummary = if (executionSuccess) "\u2713 ACTION COMPLETED: $rawActionType"
            else "\u2717 ACTION UNAVAILABLE"

            if (!executionSuccess) {
                val failMsg = "Boss, ye action Android permission ya API limitation ki wajah se directly perform nahi kar sakta."
                addMessageToChat(ChatMessage(isFromBoss = false, text = failMsg, actionSummary = actionSummary))
                ttsManager.speak(failMsg)
                resetToIdle()
                return
            }
        }

        if (action is ValidatedAction.InvalidAction) {
            ttsManager.speak("Boss, ye command allowlisted registry mein nahi hai.")
            resetToIdle()
            return
        }

        _currentState.value = JarvisState.SPEAKING
        addMessageToChat(ChatMessage(isFromBoss = false, text = spokenResponse, actionSummary = actionSummary))
        ttsManager.speak(spokenResponse)
        resetToIdle()
    }

    private fun addMessageToChat(msg: ChatMessage) {
        val currentList = _chatHistory.value.toMutableList()
        currentList.add(msg)
        _chatHistory.value = currentList
    }

    private fun resetToIdle() {
        viewModelScope.launch {
            kotlinx.coroutines.delay(2500)
            if (_currentState.value != JarvisState.LISTENING) {
                _currentState.value = JarvisState.IDLE
            }
        }
    }

    fun clearChat() {
        _chatHistory.value = emptyList()
    }
}
