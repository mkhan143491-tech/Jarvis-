package com.mohsinkhan.jarvis.data.remote

import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.POST

@JsonClass(generateAdapter = true)
data class JarvisRequest(
    val userQuery: String,
    val currentDateTime: String
)

@JsonClass(generateAdapter = true)
data class JarvisResponse(
    val type: String,
    val action: String,
    val target: String?,
    val parameters: Map<String, String>?,
    val requiresConfirmation: Boolean,
    val spokenResponse: String
)

interface JarvisBackendApi {
    @POST("/api/jarvis/v1/query")
    suspend fun sendQuery(@Body request: JarvisRequest): JarvisResponse
}
