# JARVIS — MOHSIN AI CORE

A cinematic, production-structured Android personal AI assistant, built around a secure
Backend-for-Frontend (BFF) proxy so the Gemini API key never ships inside the APK.

## Project layout

```
JarvisMohsinCore/
├── app/                        # Android client (Kotlin, Jetpack Compose, Hilt)
│   └── src/main/java/com/mohsinkhan/jarvis/
│       ├── ui/                 # Compose screens, HUD orb, JarvisViewModel
│       ├── data/remote/        # Retrofit + Moshi API layer, Hilt NetworkModule
│       ├── data/local/         # DataStore-backed MemoryManager
│       ├── domain/             # CommandValidator (LLM output -> sealed actions)
│       ├── device/             # AndroidActionManager (executes validated intents)
│       ├── audio/              # TtsManager (Hinglish text-to-speech)
│       └── service/            # Foreground voice service, Accessibility, VoiceInteraction
├── backend/                    # Node.js/Express proxy that holds GEMINI_API_KEY
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Running the backend

```bash
cd backend
npm install
cp .env.example .env   # then fill in your real GEMINI_API_KEY
npm start
```

The server listens on `POST /api/jarvis/v1/query`, injects the JARVIS system prompt and the
current server-side timestamp, calls Gemini, strips any stray markdown fences, and returns the
strict JSON action schema described in `server.js`.

## Configuring the Android client

1. Open the project in Android Studio (Hedgehog+ recommended, AGP 8.2, Kotlin 1.9.20).
2. In `app/build.gradle.kts`, point `JARVIS_BACKEND_URL` at wherever you deploy the backend
   (e.g. `https://your-app.onrender.com/`). Never point the client at Gemini directly.
3. Sync Gradle, then run on a device/emulator with API 26+.

## Security model, at a glance

- The Gemini key lives only in the backend's `.env`, never in the client.
- The client never executes free-form LLM output. Every response is deserialized into a
  `JarvisResponse`, passed through `CommandValidator`, and only recognized, well-formed actions
  reach `AndroidActionManager`, which uses standard `Intent` APIs — no shell execution, no
  hidden/private API access.
- `JarvisVoiceService` uses `ServiceCompat.startForeground(..., FOREGROUND_SERVICE_TYPE_MICROPHONE)`
  to stay compliant with Android 14's foreground-service restrictions.
- The optional `JarvisAccessibilityService` is scoped to UI navigation assistance only, and
  requires the user to manually enable it from system Settings.

## Known follow-ups (not included here)

- `SpeechRecognizer`/`AudioRecord` wiring for live mic capture (currently `MicrophoneInput`
  in `JarvisScreen.kt` is a text-entry fallback you can extend).
- Real permission-state checks in `StatusScreen` (currently illustrative placeholders — wire
  up Accompanist Permissions / `RoleManager` for the assistant role).
- Launcher icon assets (`mipmap/ic_launcher*`) — add your own via Android Studio's Image Asset tool.
